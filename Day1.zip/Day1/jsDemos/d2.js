var dev1;

(function (ns) {
    var check = function () {
        console.log("Hello");
    }

    ns.check = check;
})(dev1 = dev1 || {});