var dev1;

(function (ns) {
    var i = 10;
    console.log(i);
    console.log(typeof i);

    var hello = function () {
        console.log("Hello");
    }

    ns.hello = hello;
})(dev1 = dev1 || {});