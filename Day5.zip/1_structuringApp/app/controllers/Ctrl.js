angular.module('tApp').controller('Ctrl', ['$scope', '$log', 'DataFactory',
    function ($scope, $log, DataFactory) {
        $scope.getPosts = function () {
            DataFactory.getAllPosts().then(function (data) {
                $scope.posts = data;
            }, function (eMsg) {
                $log.error(eMsg);
            });
        }
    }]);