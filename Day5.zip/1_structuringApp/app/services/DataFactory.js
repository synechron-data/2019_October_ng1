angular.module('tApp').factory("DataFactory", function ($http, $log, $q) {
    var url = "https://jsonplaceholder.typicode.com/posts";

    return {
        getAllPosts: function () {
            var deferred = $q.defer();

            $http.get(url).then(function (response) {
                deferred.resolve(response.data);
            }, function (response) {
                deferred.reject("Communication Error....");
            });

            return deferred.promise;
        }
    };
})