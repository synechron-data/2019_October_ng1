'use strict';

angular.module('trainingAppApp', ['ngMessages', 'ngRoute'])
    .config(function ($routeProvider, $locationProvider) {

        $routeProvider.when('/check', {
            template: '<h2>This is just for check.</h2>'
        })

        $routeProvider.when('/posts', {
            templateUrl: 'views/posts.html'
        })

        $routeProvider.when('/npost', {
            templateUrl: 'views/newpost.html'
        })

        $routeProvider.when('/cd', {
            templateUrl: 'views/cd.html',
            controller: 'CDCtrl'
        })

        $routeProvider.when('/details/:id', {
            templateUrl: 'views/details.html'
        })

        $routeProvider.otherwise({
            "redirectTo": 'posts'
        })

        $locationProvider.hashPrefix('');
    })