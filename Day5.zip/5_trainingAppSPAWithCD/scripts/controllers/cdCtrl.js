'use strict';

angular.module('trainingAppApp')
    .controller('CDCtrl', function ($scope) {
        $scope.name = "Manish";
    });
