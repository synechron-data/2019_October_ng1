'use strict';

angular.module('trainingAppApp')
    .directive('postThumbnail', function () {
        //Directive Definition Object
        return {
            restrict: 'E',
            templateUrl: 'views/templates/pThumbnail.html',
            replace: true,
            scope: {
                post: "="
            }
        };
    });
