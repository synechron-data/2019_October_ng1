angular.module('trainingAppApp').directive('mySimple', function(){
    // Directive Definition Object
    return {
        restrict: 'E',
        template: '<input type="text" ng-model="name"> {{name}} <br/>',
        scope: true
    };
})