'use strict';

angular.module('trainingAppApp')
    .controller('NewpostCtrl', function (trainingDataFactory, $log, $window) {
        var self = this;

        self.open = function () {
            self.opened = true;
        };

        trainingDataFactory.getUsers().then(function (d) {
            self.users = d;
        }, function (err) {
            $log.info(err);
        });

        self.savePost = function (f, p) {
            console.log(f);
            if (f.$valid) {
                trainingDataFactory.save(p).then(function (d) {
                    $log.log(d);
                    $window.alert("Data Saved...")
                }, function (err) {
                    $log.error(err);
                });
            }
            else {
                $log.error("Invalid Entries...");
            }
        }
    });