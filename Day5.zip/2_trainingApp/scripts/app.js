'use strict';

angular.module('trainingAppApp', ['ngMessages']);